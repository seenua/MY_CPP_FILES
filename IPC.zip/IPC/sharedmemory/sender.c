#include<stdio.h>
#include<sys/types.h>
#include<sys/shm.h>
#include<sys/ipc.h>
#include<string.h>
#include<unistd.h>
#include "shared.h"


int main()
{
    char buf[SZ];

    int shmid2;
    key_t key2=101;
    SH *sm2;
    char ch;

    shmid2 = shmget(key2,sizeof(SH),IPC_CREAT|0666);
    printf("%d\n",shmid2);
    if(shmid2 == -1)
    {
        printf("shared memory2 not created\n");
    }
    sm2 = (SH *)shmat(shmid2,NULL,0);
    if((int)sm2 == -1)
    {
    	printf("shared memory2 attach process failed\n");
    } 
    sm2->status = NOTFILLED;

    do
    {
        printf("Enter data :\n");
        fgets(buf,SZ,stdin);
        if(sm2->status == NOTFILLED)
        {
            printf("Data filled successfully\n");
            strcpy(sm2->text,buf);
            sm2->status = FILLED;
        }
        while(sm2->status != NOTFILLED);

        while(sm2->status != FILLED);

        if(sm2->status == FILLED)
        {
            printf("you got a message : \n");
            printf("%s\n",sm2->text);
        }
        sm2->status = TAKEN;
        if( sm2->status == TAKEN)
        {
            printf("Making normal state\n");
            memset(sm2,'\0',sizeof(sm2));
            sm2->status = NOTFILLED;
        }

        printf("\nDo you want to continue\n");
        ch = getchar();
    }while(ch != 'q');

return 0;
}
