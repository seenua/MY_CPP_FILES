#ifndef HEADER
#define HEADER

#define SZ 100
#define NOTFILLED -1
#define FILLED 0
#define TAKEN 1

typedef struct memory
{
int status;
char text[SZ];
}SH;

#endif
