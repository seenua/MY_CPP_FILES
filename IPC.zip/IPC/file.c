#include<stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include<unistd.h>
#include<fcntl.h>

int main()
{
int res;
int fp;
char buf1[25];
char buf2[25];
mkfifo("/home/janarthanan/CPP/seenu/IPC/myfile",0777);
fp=open("/home/janarthanan/CPP/seenu/IPC/myfile",O_RDWR);
if(fp<0)
{
printf("file open sys call failed\n");
}
printf("Enter the String\n");
gets(buf1);
write(fp,buf1,sizeof(buf1));
lseek(fp,0,SEEK_SET);
read(fp,buf2,sizeof(buf2));
printf("%s\n",buf2);
close(fp);
return 0;
}
