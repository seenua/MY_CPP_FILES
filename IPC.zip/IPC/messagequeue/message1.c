#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include<string.h>
#include<stdlib.h>

#define SZ 100
int msgid1;
int msgid2;
typedef struct msg
{
long mtype;
char msg[SZ];
}MG;

MG ms1;
MG ms2;
void receiver();
void sender();

int main()
{

    char *path1 = "/home/janarthanan/CPP/seenu/IPC";
    int pd1 = 10;
    key_t key1;

    char *path2 = "/home/janarthanan/CPP/seenu/IPC";
    int pd2 = 11;
    key_t key2;

    char ch;

    key2 = ftok(path2,pd2);
    if(key2 == -1)
    {
        printf("Key2 generation failed\n");
    }
    msgid2 = msgget(key2,IPC_CREAT|0666);
    if(msgid2 == -1)
    {
        printf("msg queue2 failed\n");
    }

    key1 = ftok(path1,pd1);
    if(key1 ==-1)
    {
        printf("Key1 generation failed\n");
    }
    msgid1 = msgget(key1,IPC_CREAT|0666);
    if(msgid1 == -1)
    {
        printf("msg queue1 failed\n");
    }
    do 
    {
        printf(" ********* %c \n", ch);
        sender();
        receiver();
        printf("Do you want to continue press any key else press(q)\n");
        ch=getchar();
    }while(ch != 'q') ;

    if(msgctl(msgid1,IPC_RMID,NULL) == -1)
    {
        printf("msgid1 deleted\n");
    }
return 0;
}



void sender()
{
    char buf[SZ];
    int slen;
    printf("Enter the message to send\n");
    fgets(buf,SZ,stdin);
    ms1.mtype=1;
    slen=strlen(buf);
    strcpy(ms1.msg,buf);
    if(msgsnd(msgid1,&ms1,slen+1,0)<0)
    {
        printf("Receiver msg sending failed\n");
    }
}


void receiver()
{
    int re;
    printf("received response from the user\n");
    re=msgrcv(msgid2,&ms2,SZ,0,0);
    if(re == -1)
    {
        printf("message receive failed\n");
    }
    else
    {
        printf("%s\n",ms2.msg);
    }
}
