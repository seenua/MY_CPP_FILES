#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<sys/wait.h>
#include<stdlib.h>

int main()
{
int res;
int fd[2];
pid_t child;
int s;
char buf1[25];
char buf2[25];
int nb;
res=pipe(fd);
if(res<0)
{
perror("Pipe failed\n");
exit(1);
}
child=fork();
switch(child)
{
case -1:
       perror("fork failed\n");
       exit(1);
       break;
case 0:
      close(fd[1]);
      printf("Child process\n");
      wait(&s);
     // dup2(0,fd[0]);
      nb=read(fd[0],buf2,sizeof(buf2));
      printf("%d\n",nb);
      if(nb<0)
      {
        printf("read sys call failed\n");
        exit(1);
      }
      printf("%s\n",buf2);
      break;
default:
     close(fd[0]);
     printf("parent process\n");
     printf("Enter the String\n");
     gets(buf1);
     //dup2(1,fd[1]);
     nb=write(fd[1],buf1,sizeof(buf1));
     if(nb<0)
     {
       printf("write sys call failed\n");
       exit(1);
     }
}
return 0;
}
