#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>

int main()
{
    int ser_socfd;
    int cli_socfd;
    struct sockaddr_in server;
    struct sockaddr_in client;
    char buf[2000];
    int ret;
    int c;

    ser_socfd=socket(AF_INET,SOCK_STREAM,0);
    if( ser_socfd == -1)
    {
        printf("server socket creation failed\n");
    }
    printf("Server socket created\n");

    server.sin_family = AF_INET;
    server.sin_port   = htons(8888);
    server.sin_addr.s_addr = INADDR_ANY;
    memset(server.sin_zero,'\0',8);
    if(bind(ser_socfd,(struct sockaddr *)&server,sizeof(server))<0)
    {
        printf("bind system call failed\n");
    }
    printf("Bind done\n");
    
    listen(ser_socfd,5);
    printf("Listen executed\n");

    c=sizeof(struct sockaddr_in);

    cli_socfd = accept(ser_socfd,(struct sockaddr *)&client,(socklen_t *) &c);
    if( cli_socfd == -1)
    {
        printf("Accept failed\n");
    }
    printf("accepted connection from the client\n");
    
    while( (ret = read( cli_socfd,buf,2000))> 0)
    {
        printf("You got new message : \n");
        puts(buf);
	memset(buf,'\0',2000);
	printf("Enter your response : \n");
	fgets(buf,2000,stdin);
	write(cli_socfd,buf,strlen(buf));
    }
    
    if( ret == 0)
    {
        printf("client disconnected\n");
    }

    if( ret == -1)
    {
       printf("recv call failed\n");
    }
return 0;
}
