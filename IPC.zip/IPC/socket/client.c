#include <stdio.h>
#include <sys/socket.h>
#include <string.h>
#include <arpa/inet.h>

int main()
{
    int cli_socfd;
    struct sockaddr_in server;
    char mes[1000];
    char reply[2000];
    char ch;

    cli_socfd = socket( AF_INET , SOCK_STREAM ,0);
    if( cli_socfd == -1 )
    {
        printf("client socket creation failed\n");
    }
    printf("client socket created successfully\n");

    server.sin_family = AF_INET;
    server.sin_port   = htons(8888);
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    if( connect(cli_socfd ,(struct sockaddr *)&server ,sizeof(server))<0)
    {
        printf("connect failed\n");
    }
    printf("connected \n");

    do
    {
        printf("Enter the message : \n");
        fgets(mes,1000,stdin);
        if(write(cli_socfd,mes,strlen(mes))<0)
        {
            printf("write failed\n");
        }
        if(read(cli_socfd,reply,2000)<0)
        {
            printf("recv failed\n");
        }
	printf("you got response : \n");
	puts(reply);
        printf("Do u want to continue\n"); 
        ch =getchar();
    }while(ch != 'q');

return 0;
}
